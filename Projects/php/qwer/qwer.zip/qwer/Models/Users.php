<?php 
class Users{

var $query






	
}



 ?>