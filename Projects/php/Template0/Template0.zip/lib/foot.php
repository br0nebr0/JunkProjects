<footer><p>
График работы Call-центра <br>
В будние дни с 8 до 21 <br>
Суббота с 9 до 20 <br>
Воскресенье с 10 до 19<br></p>
<a href='admin.php'>Перейти в админ-панель</a>
<img src='img/link.jpg'>
</footer>
<?php ini_set('display_errors','On'); ?>
</div>
</body>
</html>
