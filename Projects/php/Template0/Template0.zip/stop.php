<? session_start();
  $_SESSION['admin']=false;
  header('Location:http://I-Mart.com/routes.php');
  ?>
